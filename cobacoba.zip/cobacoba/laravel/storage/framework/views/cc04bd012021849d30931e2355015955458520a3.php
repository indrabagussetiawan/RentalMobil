<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Cars</title>
</head>
<body>
    <h1>Available Cars</h1>
    <a href="<?php echo e(route('cars.create')); ?>">Add Car</a>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <button><a href="/data/users">User</a></button>
    <button><a href="/user/bookings">Booking</a></button>
    <button><a href="/returns">Return</a></button>
    <table>
        <thead>
            <tr>
                <th>Brand</th>
                <th>Model</th>
                <th>License Plate</th>
                <th>Rental Rate (per day)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($car->brand); ?></td>
                <td><?php echo e($car->model); ?></td>
                <td><?php echo e($car->plate_number); ?></td>
                <td><?php echo e($car->rental_rate); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/cars/index.blade.php ENDPATH**/ ?>