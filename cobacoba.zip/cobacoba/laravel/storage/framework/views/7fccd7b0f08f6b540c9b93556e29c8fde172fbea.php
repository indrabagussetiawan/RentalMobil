<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Car</title>
</head>
<body>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <button><a href="/data/users">User</a></button>
    <button><a href="/cars">Cars</a></button>
    <button><a href="/user/bookings">Booking</a></button>
    <h1>Return Car</h1>
    <form action="<?php echo e(route('returns.returnCar')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="plate_number">License Plate:</label><br>
        <input type="text" id="plate_number" name="plate_number"><br>

        <button type="submit">Return Car</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/returns/index.blade.php ENDPATH**/ ?>