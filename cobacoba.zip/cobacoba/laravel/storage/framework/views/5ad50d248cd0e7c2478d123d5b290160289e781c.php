<!-- resources/views/auth/login.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>

    <?php if(session('error')): ?>
        <div><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email"><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password"><br>

        <button type="submit">Login</button>
        <button><a href="/users">Register</a></button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>