<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Bookings</title>
</head>
<body>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <button><a href="/data/users">User</a></button>
    <button><a href="/cars">Cars</a></button>
    <button><a href="/bookings">Booking</a></button>
    <button><a href="/returns">Return</a></button>
    <h1>Your Bookings</h1>
    <table>
        <thead>
            <tr>
                <th>Car</th>
                <th>Start Date</th>
                <th>End Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($booking->brand); ?> - <?php echo e($booking->model); ?></td>
                <td><?php echo e($booking->start_date); ?></td>
                <td><?php echo e($booking->end_date); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/bookings/user_bookings.blade.php ENDPATH**/ ?>