<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Car</title>
</head>
<body>
    <h1>Book a Car</h1>
    <form action="<?php echo e(route('bookings.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="car_id">Select Car:</label><br>
        <select name="car_id" id="car_id">
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($car->id); ?>"><?php echo e($car->brand); ?> - <?php echo e($car->model); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <select name="user_id" id="user_id">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <label for="start_date">Start Date:</label><br>
        <input type="date" id="start_date" name="start_date"><br>

        <label for="end_date">End Date:</label><br>
        <input type="date" id="end_date" name="end_date"><br>

        <button type="submit">Book Car</button>
        <button><a href="/user/bookings">Back</a></button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/bookings/index.blade.php ENDPATH**/ ?>