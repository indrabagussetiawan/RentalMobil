<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Car</title>
</head>
<body>
    <h1>Add Car</h1>
    <form action="<?php echo e(route('cars.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="brand">Brand:</label><br>
        <input type="text" id="brand" name="brand"><br>

        <label for="model">Model:</label><br>
        <input type="text" id="model" name="model"><br>

        <label for="license_plate">License Plate:</label><br>
        <input type="text" id="license_plate" name="license_plate"><br>

        <label for="rental_rate_per_day">Rental Rate (per day):</label><br>
        <input type="text" id="rental_rate_per_day" name="rental_rate_per_day"><br>

        <button type="submit">Add Car</button>
        <button><a href="/cars">back</a></button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/cars/create.blade.php ENDPATH**/ ?>