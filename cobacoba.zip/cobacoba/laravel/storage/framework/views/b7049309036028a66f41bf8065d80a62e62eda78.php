<!DOCTYPE html>
<html>
<head>
    <title>Register User</title>
</head>
<body>
    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br>

        <label for="address">Address:</label>
        <input type="text" id="address" name="address"><br>

        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number"><br>

        <label for="license_number">License Number:</label>
        <input type="text" id="license_number" name="license_number"><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br>

        <button type="submit">Register</button>
        <button><a href="/login">Back</a></button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cobacoba\laravel\resources\views/users.blade.php ENDPATH**/ ?>