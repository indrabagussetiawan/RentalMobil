<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Car;
use App\Models\User;

class BookingController extends Controller
{
    // Menampilkan daftar mobil yang tersedia untuk disewa
    public function index()
    {
        $cars = Car::where('available', true)->get();
        $users = User::all();

        return view('bookings.index', ['cars' => $cars, 'users' => $users]);
    }

    // Menyimpan peminjaman mobil baru
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'car_id' => 'required|exists:cars,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
        ]);

        // Memeriksa ketersediaan mobil pada tanggal yang diminta
        $car = Car::findOrFail($request->car_id);
        if (!$car->available) {
            return redirect()->back()->with('error', 'Car is not available for the selected dates.');
        }

        // Menyimpan data peminjaman
        $booking = new Booking();
        $booking->car_id = $request->car_id;
        $booking->start_date = $request->start_date;
        $booking->end_date = $request->end_date;
        $booking->user_id = $request->user_id;
        $booking->save();

        // Menandai mobil sebagai tidak tersedia
        $car->available = false;
        $car->save();

        return redirect()->route('/user/bookings')->with('success', 'Car booked successfully.');
    }

    // Menampilkan daftar mobil yang sedang disewa oleh pengguna
    public function userBookings()
    {
        $bookings = Booking::join('cars', 'bookings.car_id', 'cars.id')->where('bookings.user_id', auth()->user()->id)->get();
        return view('bookings.user_bookings', ['bookings' => $bookings]);
    }
}
