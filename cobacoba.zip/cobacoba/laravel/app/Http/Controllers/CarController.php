<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Car;

class CarController extends Controller
{
    // Menampilkan semua mobil yang tersedia
    public function index()
    {
        $cars = Car::where('available', true)->get();
        return view('cars.index', ['cars' => $cars]);
    }

    // Menampilkan form tambah mobil
    public function create()
    {
        return view('cars.create');
    }

    // Menyimpan mobil baru ke dalam sistem
    public function store(Request $request)
    {
        $car = new Car();
        $car->brand = $request->brand;
        $car->model = $request->model;
        $car->plate_number = $request->license_plate;
        $car->rental_rate = $request->rental_rate_per_day;
        $car->available = true; // Mobil baru pasti tersedia
        $car->save();

        return redirect()->route('cars.index')->with('success', 'Car added successfully.');
    }

    // Mencari mobil berdasarkan merek, model, atau ketersediaan
    public function search(Request $request)
    {
        $brand = $request->brand;
        $model = $request->model;
        $availability = $request->availability;

        $query = Car::query();

        if ($brand) {
            $query->where('brand', 'LIKE', "%$brand%");
        }

        if ($model) {
            $query->where('model', 'LIKE', "%$model%");
        }

        if ($availability == 'available') {
            $query->where('available', true);
        } elseif ($availability == 'unavailable') {
            $query->where('available', false);
        }

        $cars = $query->get();

        return view('cars.search', ['cars' => $cars]);
    }
}