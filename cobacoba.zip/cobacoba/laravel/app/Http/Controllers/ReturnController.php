<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Car;

class ReturnController extends Controller
{
    // Menampilkan form pengembalian mobil
    public function index()
    {
        return view('returns.index');
    }

    // Mengembalikan mobil dan menghitung biaya sewa
    public function returnCar(Request $request)
    {
        // Validasi input
        $request->validate([
            'plate_number' => 'required|exists:cars,plate_number',
        ]);

        // Mencari pemesanan mobil berdasarkan nomor plat
        // $booking = Booking::where('car_id', function ($query) use ($request) {
        //     $query->select('id')
        //           ->from('cars')
        //           ->where('plate_number', $request->plate_number);
        // })->first();

        $booking = Booking::join('cars', 'bookings.car_id', 'cars.id')->where('cars.plate_number', $request->plate_number)->first();

        if (!$booking) {
            return redirect()->back()->with('error', 'Car with this license plate is not currently rented.');
        }

        // Menghitung jumlah hari penyewaan
        $startDate = strtotime($booking->start_date);
        $endDate = strtotime($booking->end_date);
        $numberOfDays = ceil(abs($endDate - $startDate) / 86400); // 86400 detik dalam satu hari
        
        // Menghitung biaya sewa
        $totalCost = $numberOfDays * $booking->rental_rate;
        // Mengisi data pengembalian
        $booking->end_date = now();
        $booking->total_cost = $totalCost;
        $booking->save();

        // Mengubah status ketersediaan mobil
        // Mencari mobil berdasarkan nomor plat
        $car = Car::where('plate_number', $booking->plate_number)->first();

        if ($car) {
            // Mengubah status ketersediaan mobil
            $car->update(['available' => true]);
        }

        return redirect()->back()->with('success', 'Car returned successfully. Total cost: $' . $totalCost);
    }
}

