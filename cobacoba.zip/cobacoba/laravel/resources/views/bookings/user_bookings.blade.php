<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Bookings</title>
</head>
<body>
    <form action="{{ route('logout') }}" method="POST">
        @csrf
        <button type="submit">Logout</button>
    </form>
    <button><a href="/data/users">User</a></button>
    <button><a href="/cars">Cars</a></button>
    <button><a href="/bookings">Booking</a></button>
    <button><a href="/returns">Return</a></button>
    <h1>Your Bookings</h1>
    <table>
        <thead>
            <tr>
                <th>Car</th>
                <th>Start Date</th>
                <th>End Date</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bookings as $booking)
            <tr>
                <td>{{ $booking->brand }} - {{ $booking->model }}</td>
                <td>{{ $booking->start_date }}</td>
                <td>{{ $booking->end_date }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
