<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Car</title>
</head>
<body>
    <h1>Book a Car</h1>
    <form action="{{ route('bookings.store') }}" method="POST">
        @csrf
        <label for="car_id">Select Car:</label><br>
        <select name="car_id" id="car_id">
            @foreach ($cars as $car)
            <option value="{{ $car->id }}">{{ $car->brand }} - {{ $car->model }}</option>
            @endforeach
        </select><br>

        <select name="user_id" id="user_id">
            @foreach ($users as $user)
            <option value="{{ $user->id }}">{{ $user->name }}</option>
            @endforeach
        </select><br>

        <label for="start_date">Start Date:</label><br>
        <input type="date" id="start_date" name="start_date"><br>

        <label for="end_date">End Date:</label><br>
        <input type="date" id="end_date" name="end_date"><br>

        <button type="submit">Book Car</button>
        <button><a href="/user/bookings">Back</a></button>
    </form>
</body>
</html>
