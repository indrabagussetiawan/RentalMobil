<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Cars</title>
</head>
<body>
    <h1>Available Cars</h1>
    <a href="{{ route('cars.create') }}">Add Car</a>
    <form action="{{ route('logout') }}" method="POST">
        @csrf
        <button type="submit">Logout</button>
    </form>
    <button><a href="/data/users">User</a></button>
    <button><a href="/user/bookings">Booking</a></button>
    <button><a href="/returns">Return</a></button>
    <table>
        <thead>
            <tr>
                <th>Brand</th>
                <th>Model</th>
                <th>License Plate</th>
                <th>Rental Rate (per day)</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($cars as $car)
            <tr>
                <td>{{ $car->brand }}</td>
                <td>{{ $car->model }}</td>
                <td>{{ $car->plate_number }}</td>
                <td>{{ $car->rental_rate }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>